/* SPDX-License-Identifier: BSD-3-Clause */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "fsbl_bootrom_abi.h"
#include "fsbl_config.h"

#ifndef SOC_STATUS_MAILBOX_BASE
#define SOC_STATUS_MAILBOX_BASE 0u
#endif
#ifndef SOC_QEMU_TEST_BASE
#define SOC_QEMU_TEST_BASE 0u
#endif

#define QEMU_FINISHER_FAIL 0x3333u
#define QEMU_FINISHER_PASS 0x5555u

#ifndef SOC_OPENSBI_SIZE
#define SOC_OPENSBI_SIZE 0x00050000u
#endif
#ifndef SOC_DRAM_BASE
#define SOC_DRAM_BASE UINT64_C(0x80000000)
#endif

#ifndef FSBL_INTERNAL_QSPI_LINEAR_BASE
#define FSBL_INTERNAL_QSPI_LINEAR_BASE UINT64_C(0xC0000000)
#endif
#ifndef FSBL_INTERNAL_QSPI_LINEAR_SIZE
#define FSBL_INTERNAL_QSPI_LINEAR_SIZE UINT64_C(0x04000000)
#endif
#ifndef FSBL_OPENSBI_FLASH_OFFSET
#define FSBL_OPENSBI_FLASH_OFFSET UINT64_C(0x00100000)
#endif
#define FSBL_OPENSBI_LOAD_ADDRESS SOC_DRAM_BASE
#ifndef FSBL_UBOOT_FLASH_OFFSET
#define FSBL_UBOOT_FLASH_OFFSET UINT64_C(0x00300000)
#endif
#ifndef FSBL_UBOOT_LOAD_ADDRESS
#define FSBL_UBOOT_LOAD_ADDRESS UINT64_C(0x80200000)
#endif
#ifndef FSBL_UBOOT_SIZE
#define FSBL_UBOOT_SIZE UINT64_C(0x00090000)
#endif
#define FSBL_COPY_PROGRESS_INTERVAL (1024u * 1024u)
#define FSBL_READY_MAGIC UINT32_C(0x4653424C)

extern void _fsbl_start(void);
void fsbl_main(uint64_t hart_id, const bootrom_info_t *info)
    __attribute__((noreturn));

static uint32_t g_demo_heartbeat __attribute__((unused));
/* A nonzero initializer puts this in the FSBL image's .data section.  A
 * secondary arriving before HART0 clears BSS must never see stale READY.
 * This synchronization is required both when OpenOCD starts the FSBL
 * directly and when the BootROM autoloads it from QSPI. */
#if defined(SOC_QSPI_INTERNAL_LINEAR_READ)
static volatile uint32_t g_fsbl_ready = UINT32_C(0x57414954);
_Static_assert(BOOTROM_BOOT_HART == 0, "startup BSS owner must be HART0");
#endif
static void demo_uart_puts(const char *text);
static bool demo_uart_putc(char c);

#if defined(FSBL_OPENSBI_CRC32) && defined(FSBL_UBOOT_CRC32)
static void demo_uart_hex32(uint32_t value) {
  static const char digits[] = "0123456789abcdef";
  for (uint32_t shift = 32u; shift != 0u; shift -= 4u) {
    (void)demo_uart_putc(digits[(value >> (shift - 4u)) & 15u]);
  }
}

static bool fsbl_verify_image(const char *name, uint64_t address,
                              size_t size, uint32_t expected_crc) {
  const volatile uint8_t *bytes = (const volatile uint8_t *)(uintptr_t)address;
  uint32_t crc = UINT32_MAX;
  __asm__ volatile("fence rw, rw" ::: "memory");
  for (size_t index = 0u; index < size; ++index) {
    crc ^= bytes[index];
    for (uint32_t bit = 0u; bit < 8u; ++bit) {
      const uint32_t mask = 0u - (crc & 1u);
      crc = (crc >> 1u) ^ (UINT32_C(0xedb88320) & mask);
    }
  }
  crc ^= UINT32_MAX;
  demo_uart_puts("FSBL verify ");
  demo_uart_puts(name);
  demo_uart_puts(": crc32=0x");
  demo_uart_hex32(crc);
  demo_uart_puts(" expected=0x");
  demo_uart_hex32(expected_crc);
  demo_uart_puts(crc == expected_crc ? " OK\n" : " FAIL\n");
  return crc == expected_crc;
}
#endif

static inline __attribute__((unused)) uint8_t mmio_read8(uintptr_t address) {
  return *(volatile uint8_t *)address;
}
static inline __attribute__((unused)) void mmio_write8(uintptr_t address,
                                                        uint8_t value) {
  *(volatile uint8_t *)address = value;
}
static inline __attribute__((unused)) uint32_t mmio_read32(uintptr_t address) {
  return *(volatile uint32_t *)address;
}
static inline __attribute__((unused)) void mmio_write32(uintptr_t address, uint32_t value) {
  *(volatile uint32_t *)address = value;
}

#if defined(SOC_QSPI_INTERNAL_LINEAR_READ)
static void fsbl_memcpy_from_linear(void *destination, const void *source,
                                    size_t size) {
  uint8_t *output = (uint8_t *)destination;
  const volatile uint8_t *input = (const volatile uint8_t *)source;
  size_t progress_bytes = 0u;

  /* The new direct Rocket-to-PS GP0 path completes byte and half-word QSPI
   * reads, but a running hart stalls on the corresponding 32-bit read.  Use
   * byte transactions for this XIP copy until the fabric is regenerated with
   * a fully supported word-read path. */
  for (size_t index = 0u; index < size; ++index) {
    output[index] = input[index];
    ++progress_bytes;
    if (progress_bytes == FSBL_COPY_PROGRESS_INTERVAL) {
      demo_uart_puts(".");
      progress_bytes = 0u;
    }
  }
}

static bool fsbl_copy_linear_image(const char *name, uint64_t flash_offset,
                                   uint64_t load_address, uint64_t image_size) {
  if (image_size == 0u || flash_offset > FSBL_INTERNAL_QSPI_LINEAR_SIZE ||
      image_size > FSBL_INTERNAL_QSPI_LINEAR_SIZE - flash_offset ||
      flash_offset > UINT64_MAX - FSBL_INTERNAL_QSPI_LINEAR_BASE ||
      load_address > UINTPTR_MAX || image_size > SIZE_MAX) {
    return false;
  }

  const uint64_t source_address =
      FSBL_INTERNAL_QSPI_LINEAR_BASE + flash_offset;
  if (source_address > UINTPTR_MAX ||
      image_size - 1u > UINTPTR_MAX - (uintptr_t)source_address ||
      image_size - 1u > UINTPTR_MAX - (uintptr_t)load_address) {
    return false;
  }

  demo_uart_puts("FSBL copy ");
  demo_uart_puts(name);
  demo_uart_puts(": ");
  fsbl_memcpy_from_linear((void *)(uintptr_t)load_address,
                          (const void *)(uintptr_t)source_address,
                          (size_t)image_size);
  demo_uart_puts(" done\n");
  return true;
}

static bool fsbl_load_next_stages(void) __attribute__((unused));
static bool fsbl_load_next_stages(void) {
  if (!fsbl_copy_linear_image("OpenSBI", FSBL_OPENSBI_FLASH_OFFSET,
                              FSBL_OPENSBI_LOAD_ADDRESS, SOC_OPENSBI_SIZE)) {
    return false;
  }
#if defined(FSBL_OPENSBI_CRC32) && defined(FSBL_UBOOT_CRC32)
  if (!fsbl_verify_image("OpenSBI", FSBL_OPENSBI_LOAD_ADDRESS,
                          SOC_OPENSBI_SIZE, FSBL_OPENSBI_CRC32)) {
    return false;
  }
#endif
  if (!fsbl_copy_linear_image("U-Boot", FSBL_UBOOT_FLASH_OFFSET,
                              FSBL_UBOOT_LOAD_ADDRESS, FSBL_UBOOT_SIZE)) {
    return false;
  }
#if defined(FSBL_OPENSBI_CRC32) && defined(FSBL_UBOOT_CRC32)
  if (!fsbl_verify_image("U-Boot", FSBL_UBOOT_LOAD_ADDRESS,
                          FSBL_UBOOT_SIZE, FSBL_UBOOT_CRC32)) {
    return false;
  }
#endif

  __asm__ volatile("fence rw, rw\n"
                   "fence.i\n" ::: "memory");
  return true;
}

_Static_assert(SOC_OPENSBI_SIZE != 0u, "OpenSBI image size is zero");
_Static_assert(FSBL_OPENSBI_FLASH_OFFSET + (uint64_t)SOC_OPENSBI_SIZE <=
                   FSBL_INTERNAL_QSPI_LINEAR_SIZE,
               "OpenSBI exceeds internal QSPI");
_Static_assert(FSBL_UBOOT_FLASH_OFFSET + FSBL_UBOOT_SIZE <=
                   FSBL_INTERNAL_QSPI_LINEAR_SIZE,
               "U-Boot exceeds internal QSPI");
_Static_assert(FSBL_OPENSBI_LOAD_ADDRESS + (uint64_t)SOC_OPENSBI_SIZE <=
                   FSBL_UBOOT_LOAD_ADDRESS,
               "OpenSBI and U-Boot load ranges overlap");
#endif


static bool demo_uart_putc(char c) {
#if SOC_UART_KIND == BOOTROM_UART_NS16550
  for (uint32_t count = 0u; count < BOOTROM_POLL_TIMEOUT; ++count) {
    if ((mmio_read8((uintptr_t)SOC_UART_BASE + 5u) & (1u << 5)) != 0u) {
      mmio_write8((uintptr_t)SOC_UART_BASE, (uint8_t)c);
      return true;
    }
  }
  return false;
#elif SOC_UART_KIND == BOOTROM_UART_MMIO32
  for (uint32_t count = 0u; count < BOOTROM_POLL_TIMEOUT; ++count) {
#if SOC_UART_HAS_STATUS
    if ((mmio_read32((uintptr_t)SOC_UART_BASE + SOC_UART_STATUS_OFFSET) &
         SOC_UART_READY_MASK) != SOC_UART_READY_VALUE) {
      continue;
    }
#endif
    mmio_write32((uintptr_t)SOC_UART_BASE + SOC_UART_TXDATA_OFFSET,
                 (uint32_t)(uint8_t)c);
    return true;
  }
  return false;
#elif SOC_UART_KIND == BOOTROM_UART_SIFIVE
  for (uint32_t count = 0u; count < BOOTROM_POLL_TIMEOUT; ++count) {
    if ((mmio_read32((uintptr_t)SOC_UART_BASE) & (1u << 31)) == 0u) {
      mmio_write32((uintptr_t)SOC_UART_BASE, (uint32_t)(uint8_t)c);
      return true;
    }
  }
  return false;
#else
  (void)c;
  return false;
#endif
}

static void demo_uart_puts(const char *text) {
  while (text != NULL && *text != '\0') {
    if (*text == '\n') {
      (void)demo_uart_putc('\r');
    }
    if (!demo_uart_putc(*text++)) {
      return;
    }
  }
}

static void demo_trace(uint32_t event, uint32_t error, uint64_t value) {
#if SOC_STATUS_MAILBOX_BASE != 0
  const uintptr_t base = (uintptr_t)SOC_STATUS_MAILBOX_BASE;
  ++g_demo_heartbeat;
  mmio_write32(base + BOOTROM_TRACE_REG_MAGIC, BOOTROM_TRACE_MAGIC);
  mmio_write32(base + BOOTROM_TRACE_REG_VERSION, BOOTROM_TRACE_VERSION);
  mmio_write32(base + BOOTROM_TRACE_REG_EVENT, event);
  mmio_write32(base + BOOTROM_TRACE_REG_STAGE, 0xF5B1u);
  mmio_write32(base + BOOTROM_TRACE_REG_ERROR, error);
  mmio_write32(base + BOOTROM_TRACE_REG_HART, 0u);
  mmio_write32(base + BOOTROM_TRACE_REG_VALUE_LO, (uint32_t)value);
  mmio_write32(base + BOOTROM_TRACE_REG_VALUE_HI, (uint32_t)(value >> 32u));
  __asm__ volatile("fence iorw, iorw" ::: "memory");
  mmio_write32(base + BOOTROM_TRACE_REG_HEARTBEAT, g_demo_heartbeat);
  __asm__ volatile("fence iorw, iorw" ::: "memory");
#else
  (void)event;
  (void)error;
  (void)value;
#endif
}

static void demo_finish(bool pass, uint32_t code) __attribute__((noreturn));
static void demo_finish(bool pass, uint32_t code) {
  demo_trace(BOOTROM_TRACE_EVENT_FSBL, pass ? 0u : code,
             pass ? 0x50415353u : 0x4641494Cu);
#if SOC_QEMU_TEST_BASE != 0
  const uint32_t status = pass ? QEMU_FINISHER_PASS : QEMU_FINISHER_FAIL;
  __asm__ volatile("fence iorw, iorw" ::: "memory");
  mmio_write32((uintptr_t)SOC_QEMU_TEST_BASE, (code << 16u) | status);
  __asm__ volatile("fence iorw, iorw" ::: "memory");
#endif
  for (;;) {
    __asm__ volatile("wfi");
  }
}

#if defined(SOC_QSPI_INTERNAL_LINEAR_READ)
typedef void (*next_stage_entry_t)(uint64_t hart_id, uint64_t arg1);

static void next_stage_handoff(uint64_t hart_id, uint64_t arg1)
    __attribute__((noreturn));

static void next_stage_handoff(uint64_t hart_id, uint64_t arg1) {
  next_stage_entry_t entry =
      (next_stage_entry_t)(uintptr_t)SOC_DRAM_BASE;

  __asm__ volatile(
      "csrw mie, zero\n"
      "csrci mstatus, 8\n"
      "fence iorw, iorw\n"
      "fence.i\n"
      ::: "memory");

  entry(hart_id, arg1);

  /* Không được phép quay lại FSBL. */
  demo_finish(false, 4u);
}
#endif

void fsbl_main(uint64_t hart_id, const bootrom_info_t *info) {
  // if (hart_id != BOOTROM_BOOT_HART) {
  //   demo_uart_puts("FSBL FAIL hart\n");
  //   demo_finish(false, 1u);
  // }
  // if (info == NULL || info->magic != BOOTROM_INFO_MAGIC ||
  //     info->abi_major != BOOTROM_INFO_ABI_MAJOR ||
  //     info->abi_minor != BOOTROM_INFO_ABI_MINOR ||
  //     info->struct_size != sizeof(*info)) {
  //   demo_uart_puts("FSBL FAIL boot_info\n");
  //   demo_finish(false, 2u);
  // }
  // if (info->selected_slot >= BOOTROM_SLOT_COUNT ||
  //     info->image_load_address != (uint64_t)SOC_EXEC_RAM_BASE ||
  //     info->image_entry_address != (uint64_t)(uintptr_t)&_fsbl_start ||
  //     info->image_size < BOOTROM_ENTRY_ALIGNMENT ||
  //     info->platform_id != SOC_PLATFORM_ID ||
  //     info->manifest_version != BOOTROM_MANIFEST_VERSION ||
  //     (info->image_flags & BOOTROM_IMAGE_FLAG_EXECUTABLE) == 0u ||
  //     (info->attempted_slots & (1u << info->selected_slot)) == 0u ||
  //     (info->flags & BOOTROM_INFO_FLAG_PLATFORM_READY) == 0u ||
  //     info->boot_stage != BOOTROM_STAGE_HANDOFF ||
  //     info->last_error != BOOTROM_OK) {
  //   demo_uart_puts("FSBL FAIL handoff\n");
  //   demo_finish(false, 3u);
  // }

  // demo_uart_puts("FSBL VALIDATION PASS\n");
#if defined(SOC_QSPI_INTERNAL_LINEAR_READ)
  /* The BootROM resumes every configured hart at the FSBL entry.  Only the
   * boot hart may touch QSPI or the shared DDR destinations; otherwise the
   * two copies race and the secondary can enter OpenSBI while HART0 is still
   * preparing it. */
  if (hart_id != BOOTROM_BOOT_HART) {
    while (g_fsbl_ready != FSBL_READY_MAGIC) {
      __asm__ volatile("" ::: "memory");
    }
    __asm__ volatile("fence r, rw" ::: "memory");
#if defined(FSBL_DIRECT_JTAG)
    /* Direct JTAG starts the raw FSBL payload, so a1 is already the Linux
     * DTB address supplied by OpenOCD; there is no BootROM info structure. */
    next_stage_handoff(hart_id, (uint64_t)(uintptr_t)info);
#else
    next_stage_handoff(hart_id, info->dtb_address);
#endif
  }
#if defined(FSBL_PRELOADED_JTAG)
#if defined(FSBL_DIRECT_JTAG)
  demo_uart_puts("FSBL using JTAG-preloaded OpenSBI and U-Boot\n");
  __asm__ volatile("fence rw, rw\n" ::: "memory");
  g_fsbl_ready = FSBL_READY_MAGIC;
  next_stage_handoff(hart_id, (uint64_t)(uintptr_t)info);
#else
  demo_uart_puts("FSBL FAIL preloaded mode requires direct JTAG\n");
  demo_finish(false, 8u);
#endif
#else
  demo_uart_puts("FSBL loading OpenSBI and U-Boot from internal QSPI\n");
  if (!fsbl_load_next_stages()) {
    demo_uart_puts("FSBL FAIL next-stage load/verify; handoff blocked\n");
    demo_finish(false, 6u);
  }
  demo_uart_puts("FSBL OpenSBI and U-Boot loaded\n");
#if defined(FSBL_DIRECT_JTAG)
  demo_uart_puts("FSBL HART0 handoff -> OpenSBI\n");
  /* Publish only after every image store is visible to the other hart. */
  __asm__ volatile("fence rw, rw\n" ::: "memory");
  g_fsbl_ready = FSBL_READY_MAGIC;
  /* Direct JTAG starts the raw FSBL payload, so a1 is already the Linux
   * DTB address supplied by OpenOCD; there is no BootROM info structure. */
  next_stage_handoff(hart_id, (uint64_t)(uintptr_t)info);
#else
  next_stage_handoff(hart_id, info->dtb_address);
#endif
#endif
#else
  demo_uart_puts("FSBL FAIL internal QSPI unavailable\n");
  demo_finish(false, 7u);
#endif
}
