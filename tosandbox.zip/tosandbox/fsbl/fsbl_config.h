/* SPDX-License-Identifier: BSD-3-Clause */
#ifndef DEMO_FSBL_CONFIG_H
#define DEMO_FSBL_CONFIG_H

/* Standalone defaults matching the rtl_fpga platform. */
#ifndef SOC_EXEC_RAM_BASE
#define SOC_EXEC_RAM_BASE 0x08002000
#endif
#ifndef SOC_EXEC_RAM_SIZE
#define SOC_EXEC_RAM_SIZE 0x0007E000
#endif

#ifndef SOC_UART_BASE
#define SOC_UART_BASE 0x10020000UL
#endif
#ifndef SOC_UART_KIND
#define SOC_UART_KIND BOOTROM_UART_SIFIVE
#endif
#ifndef SOC_UART_TXDATA_OFFSET
#define SOC_UART_TXDATA_OFFSET 0x00u
#endif
#ifndef SOC_UART_HAS_STATUS
#define SOC_UART_HAS_STATUS 1
#endif
#ifndef SOC_UART_STATUS_OFFSET
#define SOC_UART_STATUS_OFFSET 0x04u
#endif
#ifndef SOC_UART_READY_MASK
#define SOC_UART_READY_MASK 0x1u
#endif
#ifndef SOC_UART_READY_VALUE
#define SOC_UART_READY_VALUE 0x1u
#endif

#ifndef SOC_STATUS_MAILBOX_BASE
#define SOC_STATUS_MAILBOX_BASE 0u
#endif
#ifndef SOC_QEMU_TEST_BASE
#define SOC_QEMU_TEST_BASE 0u
#endif
/* The new Rocket RTL maps the ZynqMP internal QSPI through the PS LQSPI
 * aperture.  Use that 64 MiB window directly; the SiFive SPI controller at
 * 0x10030000 belongs to the separate external flash and is intentionally not
 * touched by this FSBL. */
#ifndef SOC_QSPI_INTERNAL_LINEAR_READ
#define SOC_QSPI_INTERNAL_LINEAR_READ 1
#endif
#ifndef FSBL_INTERNAL_QSPI_LINEAR_BASE
#define FSBL_INTERNAL_QSPI_LINEAR_BASE 0xC0000000ULL
#endif
#ifndef FSBL_INTERNAL_QSPI_LINEAR_SIZE
#define FSBL_INTERNAL_QSPI_LINEAR_SIZE 0x04000000ULL
#endif

#ifndef SOC_DRAM_BASE
#define SOC_DRAM_BASE 0x80000000ULL
#endif
#ifndef SOC_OPENSBI_SIZE
#define SOC_OPENSBI_SIZE 0x00050000u
#endif

/* Each direct-JTAG hart gets a private FSBL stack.  HART0 performs the
 * storage copy; secondary harts wait for its completion before entering
 * OpenSBI, so they never execute the copy path concurrently. */
#ifndef FSBL_STACK_STRIDE
#define FSBL_STACK_STRIDE 0x1000
#endif
#ifndef FSBL_HART_COUNT
#define FSBL_HART_COUNT 2
#endif

#endif
