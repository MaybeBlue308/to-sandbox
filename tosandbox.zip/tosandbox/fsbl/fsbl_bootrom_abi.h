/* SPDX-License-Identifier: BSD-3-Clause */
#ifndef DEMO_FSBL_BOOTROM_ABI_H
#define DEMO_FSBL_BOOTROM_ABI_H

#include <stddef.h>
#include <stdint.h>

#define BOOTROM_BOOT_HART 0
#define BOOTROM_SLOT_COUNT 2u
#define BOOTROM_POLL_TIMEOUT 1000000u
#define BOOTROM_ENTRY_ALIGNMENT 4u

#define BOOTROM_UART_NONE 0
#define BOOTROM_UART_NS16550 1
#define BOOTROM_UART_MMIO32 2
#define BOOTROM_UART_SIFIVE 3

#define BOOTROM_INFO_MAGIC 0x424F4F54u
#define BOOTROM_INFO_ABI_MAJOR 1u
#define BOOTROM_INFO_ABI_MINOR 6u
#define BOOTROM_INFO_FLAG_PLATFORM_READY (1u << 3)
#define BOOTROM_IMAGE_FLAG_EXECUTABLE (1u << 0)
#define BOOTROM_MANIFEST_VERSION 2u

#define BOOTROM_TRACE_MAGIC 0x42545243u
#define BOOTROM_TRACE_VERSION 1u
#define BOOTROM_TRACE_EVENT_FSBL 0x4653424Cu
#define BOOTROM_TRACE_REG_MAGIC 0x00u
#define BOOTROM_TRACE_REG_VERSION 0x04u
#define BOOTROM_TRACE_REG_EVENT 0x08u
#define BOOTROM_TRACE_REG_STAGE 0x0Cu
#define BOOTROM_TRACE_REG_ERROR 0x10u
#define BOOTROM_TRACE_REG_HART 0x14u
#define BOOTROM_TRACE_REG_VALUE_LO 0x18u
#define BOOTROM_TRACE_REG_VALUE_HI 0x1Cu
#define BOOTROM_TRACE_REG_HEARTBEAT 0x20u

typedef enum {
  BOOTROM_OK = 0,
  BOOTROM_ERROR_INTERNAL = 0x7F
} bootrom_error_t;

typedef enum {
  BOOTROM_STAGE_RESET = 0,
  BOOTROM_STAGE_HANDOFF = 10
} bootrom_stage_t;

typedef struct {
  uint32_t magic;
  uint16_t abi_major;
  uint16_t abi_minor;
  uint32_t struct_size;
  uint32_t bootrom_version;
  uint32_t flags;
  uint32_t selected_slot;
  uint32_t reset_reason;
  uint32_t last_error;
  uint32_t slot_error[2];
  uint32_t image_flags;
  uint32_t image_version;
  uint32_t platform_id;
  uint32_t image_size;
  uint64_t image_load_address;
  uint64_t image_entry_address;
  uint64_t dtb_address;
  uint64_t platform_data;
  uint64_t trap_cause;
  uint64_t trap_epc;
  uint64_t trap_tval;
  uint32_t boot_stage;
  uint32_t attempted_slots;
  uint32_t manifest_version;
  uint32_t payload_crc32;
} bootrom_info_t;

_Static_assert(sizeof(bootrom_info_t) == 128u, "bootrom_info_t size");
_Static_assert(offsetof(bootrom_info_t, dtb_address) == 72u,
               "bootrom_info_t dtb_address offset");

#endif
