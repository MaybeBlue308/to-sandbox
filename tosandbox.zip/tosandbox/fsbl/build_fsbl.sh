#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${1:-${SCRIPT_DIR}/out}"
LOAD_ADDRESS="${FSBL_LOAD_ADDRESS:-0x08002000}"
EXEC_SIZE="${FSBL_EXEC_SIZE:-0x0007E000}"
PLATFORM_ID="${FSBL_PLATFORM_ID:-0x52544C46}"
IMAGE_VERSION="${FSBL_IMAGE_VERSION:-1}"
SLOT_SIZE="${FSBL_SLOT_SIZE:-0x00100000}"
DIRECT_JTAG="${FSBL_DIRECT_JTAG:-0}"
PRELOADED_JTAG="${FSBL_PRELOADED_JTAG:-0}"
QSPI_LINEAR_BASE="${FSBL_QSPI_LINEAR_BASE:-0xC0000000}"
QSPI_LINEAR_SIZE="${FSBL_QSPI_LINEAR_SIZE:-0x04000000}"
OPENSBI_FLASH_OFFSET="${FSBL_OPENSBI_FLASH_OFFSET:-0x00100000}"
OPENSBI_LOAD_ADDRESS="${FSBL_OPENSBI_LOAD_ADDRESS:-0x80000000}"
OPENSBI_SIZE="${FSBL_OPENSBI_SIZE:-0x00050000}"
UBOOT_FLASH_OFFSET="${FSBL_UBOOT_FLASH_OFFSET:-0x00300000}"
UBOOT_LOAD_ADDRESS="${FSBL_UBOOT_LOAD_ADDRESS:-0x80200000}"
UBOOT_SIZE="${FSBL_UBOOT_SIZE:-0x00090000}"

mkdir -p "${OUTPUT_DIR}"

if command -v clang >/dev/null 2>&1 && command -v ld.lld >/dev/null 2>&1; then
  CC="${CC:-clang}"
  OBJCOPY="${OBJCOPY:-llvm-objcopy}"
  if command -v llvm-nm >/dev/null 2>&1; then
    NM="${NM:-llvm-nm}"
  elif command -v riscv64-unknown-elf-nm >/dev/null 2>&1; then
    NM="${NM:-riscv64-unknown-elf-nm}"
  else
    NM="${NM:-nm}"
  fi
  TARGET_FLAGS=(--target=riscv64-unknown-elf)
  LINKER_FLAGS=(-fuse-ld=lld)
elif command -v riscv64-unknown-elf-gcc >/dev/null 2>&1; then
  CC="${CC:-riscv64-unknown-elf-gcc}"
  OBJCOPY="${OBJCOPY:-riscv64-unknown-elf-objcopy}"
  NM="${NM:-riscv64-unknown-elf-nm}"
  TARGET_FLAGS=()
  LINKER_FLAGS=(-Wl,--no-warn-rwx-segments)
else
  echo "error: need clang+LLD or riscv64-unknown-elf-gcc" >&2
  exit 1
fi

for tool in "${CC}" "${OBJCOPY}" "${NM}" python3; do
  if ! command -v "${tool}" >/dev/null 2>&1; then
    echo "error: required tool not found: ${tool}" >&2
    exit 1
  fi
done

COMMON_FLAGS=(
  "${TARGET_FLAGS[@]}"
  -march=rv64imac_zicsr_zifencei
  -mabi=lp64
  -mcmodel=medany
  -mstrict-align
  -msmall-data-limit=0
  -ffreestanding
  -fno-builtin
  -fno-common
  -fstack-protector-strong
  -fno-pic
  -fno-unwind-tables
  -fno-asynchronous-unwind-tables
  -fdata-sections
  -ffunction-sections
  -Os
  -g0
  -I"${SCRIPT_DIR}"
  -DSOC_EXEC_RAM_BASE="${LOAD_ADDRESS}"
  -DSOC_EXEC_RAM_SIZE="${EXEC_SIZE}"
  -DFSBL_INTERNAL_QSPI_LINEAR_BASE="${QSPI_LINEAR_BASE}"
  -DFSBL_INTERNAL_QSPI_LINEAR_SIZE="${QSPI_LINEAR_SIZE}"
  -DFSBL_OPENSBI_FLASH_OFFSET="${OPENSBI_FLASH_OFFSET}"
  -DSOC_DRAM_BASE="${OPENSBI_LOAD_ADDRESS}"
  -DSOC_OPENSBI_SIZE="${OPENSBI_SIZE}"
  -DFSBL_UBOOT_FLASH_OFFSET="${UBOOT_FLASH_OFFSET}"
  -DFSBL_UBOOT_LOAD_ADDRESS="${UBOOT_LOAD_ADDRESS}"
  -DFSBL_UBOOT_SIZE="${UBOOT_SIZE}"
)

if [[ "${DIRECT_JTAG}" == "1" ]]; then
  COMMON_FLAGS+=("-DFSBL_DIRECT_JTAG=1")
fi
if [[ "${PRELOADED_JTAG}" == "1" ]]; then
  COMMON_FLAGS+=("-DFSBL_PRELOADED_JTAG=1")
fi
if [[ -n "${FSBL_OPENSBI_CRC32:-}" || -n "${FSBL_UBOOT_CRC32:-}" ]]; then
  : "${FSBL_OPENSBI_CRC32:?both next-stage CRC32 values are required}"
  : "${FSBL_UBOOT_CRC32:?both next-stage CRC32 values are required}"
  COMMON_FLAGS+=(
    -DFSBL_OPENSBI_CRC32="${FSBL_OPENSBI_CRC32}"
    -DFSBL_UBOOT_CRC32="${FSBL_UBOOT_CRC32}"
  )
fi

"${CC}" "${TARGET_FLAGS[@]}" -E -P -x c -I"${SCRIPT_DIR}" \
  -DSOC_EXEC_RAM_BASE="${LOAD_ADDRESS}" \
  -DSOC_EXEC_RAM_SIZE="${EXEC_SIZE}" \
  "${SCRIPT_DIR}/linker.ld.S" -o "${OUTPUT_DIR}/demo_fsbl.ld"

"${CC}" "${COMMON_FLAGS[@]}" -c "${SCRIPT_DIR}/start.S" \
  -o "${OUTPUT_DIR}/start.o"
"${CC}" "${COMMON_FLAGS[@]}" \
  -Wall -Wextra -Werror -Wpedantic -Wconversion -Wshadow -Wundef \
  -Wcast-align -Wstrict-prototypes -Wmissing-prototypes -Wformat=2 -Wvla \
  -c "${SCRIPT_DIR}/main.c" -o "${OUTPUT_DIR}/main.o"

"${CC}" "${TARGET_FLAGS[@]}" -march=rv64imac_zicsr_zifencei -mabi=lp64 \
  -mcmodel=medany -nostdlib "${OUTPUT_DIR}/start.o" "${OUTPUT_DIR}/main.o" \
  -Wl,-T,"${OUTPUT_DIR}/demo_fsbl.ld" \
  -Wl,-Map,"${OUTPUT_DIR}/demo_fsbl.map" \
  -Wl,--gc-sections -Wl,--build-id=none -Wl,--fatal-warnings \
  "${LINKER_FLAGS[@]}" -o "${OUTPUT_DIR}/demo_fsbl.elf"

"${OBJCOPY}" -O binary "${OUTPUT_DIR}/demo_fsbl.elf" \
  "${OUTPUT_DIR}/demo_fsbl_payload.bin"

ENTRY_ADDRESS="$(${NM} -n "${OUTPUT_DIR}/demo_fsbl.elf" | \
  awk '$3 == "_fsbl_start" { print "0x" $1; exit }')"
if [[ -z "${ENTRY_ADDRESS}" ]]; then
  echo "error: _fsbl_start is missing from demo_fsbl.elf" >&2
  exit 1
fi

python3 - "${OUTPUT_DIR}/demo_fsbl_payload.bin" \
  "${OUTPUT_DIR}/demo_fsbl.bin" "${LOAD_ADDRESS}" "${ENTRY_ADDRESS}" \
  "${PLATFORM_ID}" "${IMAGE_VERSION}" "${SLOT_SIZE}" <<'PY'
import binascii
import pathlib
import struct
import sys

payload_path, output_path = map(pathlib.Path, sys.argv[1:3])
load, entry, platform_id, version, slot_size = (int(value, 0) for value in sys.argv[3:])
payload = payload_path.read_bytes()
header_size = 64
if not payload or len(payload) + header_size > slot_size:
    raise SystemExit("error: FSBL payload does not fit the configured slot")
if load % 8 or entry % 4 or not load <= entry < load + len(payload):
    raise SystemExit("error: invalid FSBL load/entry address")

fmt = "<IHHIIQQIIIHHI12s"
fields = (
    0x42524F4D, 2, header_size, len(payload),
    binascii.crc32(payload) & 0xFFFFFFFF,
    load, entry, 1, version, platform_id, 1, 0, 0, bytes(12),
)
header_without_crc = struct.pack(fmt, *fields)
header_crc = binascii.crc32(header_without_crc) & 0xFFFFFFFF
header = struct.pack(fmt, *(fields[:12] + (header_crc, fields[13])))
output_path.write_bytes(header + payload)
print(f"wrote {output_path}: manifest=64 payload={len(payload)} total={len(header) + len(payload)}")
print(f"  load=0x{load:016x} entry=0x{entry:016x} platform=0x{platform_id:08x}")
print(f"  header_crc32=0x{header_crc:08x} payload_crc32=0x{fields[4]:08x}")
PY
